import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatButtonModule, MatSelectModule,
  MatDatepickerModule, MatInputModule, MatTableModule, MatFormFieldModule, MatIconModule} from '@angular/material';
import { MatNativeDateModule } from '@angular/material';
// import { MomentDateAdapter} from '@angular/material-moment-adapter';
// import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { HttpClientModule } from '@angular/common/http';

// export const MY_FORMATS = {
  // parse: {
  //   dateInput: 'Do MMM YY',
  // },
  // display: {
  //   dateInput: 'Do MMM YY',
  //   monthYearLabel: 'MMM YY',
  //   dateA11yLabel: 'Do',
  //   monthYearA11yLabel: 'MMMM YY',
  // },
// };

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatDatepickerModule,
    MatInputModule,
    MatTableModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    FormsModule,
    MatNativeDateModule,
    HttpClientModule,
    MatIconModule,
    MatSelectModule,
  ],
  providers: [
   // {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
   // {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
