package com.user.dto;

import java.util.Date;
import javax.validation.constraints.Email;

public class UserDto {

	private String fname;

	private String lname;

	@Email
	private String username;

	private String password;

	private PhoneDto1 contact1;

	private PhoneDto2 contact2;

	private Date dob;

	private AddressDto addressDto;

//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public PhoneDto1 getContact1() {
		return contact1;
	}

	public void setContact1(PhoneDto1 contact1) {
		this.contact1 = contact1;
	}

	public PhoneDto2 getContact2() {
		return contact2;
	}

	public void setContact2(PhoneDto2 contact2) {
		this.contact2 = contact2;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public AddressDto getAddress() {
		return addressDto;
	}

	public void setAddress(AddressDto addressDto) {
		this.addressDto = addressDto;
	}

	public UserDto() {
		super();
	}
}
