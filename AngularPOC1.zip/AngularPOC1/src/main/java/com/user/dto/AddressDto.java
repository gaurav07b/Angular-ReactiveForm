package com.user.dto;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class AddressDto {

	private int id;
	
	private String hno;
	
	private String locality;
	
	private String state;
	
	private String pin;
	
    private Set<UserDto> userDto;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHno() {
		return hno;
	}

	public void setHno(String hno) {
		this.hno = hno;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	@JsonIgnore
	public Set<UserDto> getUser() {
		return userDto;
	}

	public void setUser(Set<UserDto> userDto) {
		this.userDto = userDto;
	}

	public AddressDto() {
		super();
	}
	
}
