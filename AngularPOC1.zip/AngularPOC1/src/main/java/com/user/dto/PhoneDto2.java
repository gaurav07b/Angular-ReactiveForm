package com.user.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class PhoneDto2 {

	private int phoneid;
	
	private String area;
	
	private String tele;

    private UserDto userDto;
	
	public int getPhoneid() {
		return phoneid;
	}

	public void setPhoneid(int phoneid) {
		this.phoneid = phoneid;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getTele() {
		return tele;
	}

	public void setTele(String tele) {
		this.tele = tele;
	}

	@JsonIgnore
	public UserDto getUser() {
		return userDto;
	}

	public void setUser(UserDto userDto) {
		this.userDto = userDto;
	}

	public PhoneDto2() {
		super();
	}
	
}
