package com.user.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.dao.entity.LoginUser;
import com.user.dao.entity.User;
import com.user.dto.UserDto;
import com.user.service.IUserServ;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private IUserServ userserv;
	
	@PostMapping("/signup")
	User addnew(@Valid @RequestBody UserDto user) {
		return userserv.addnewUser(user); 
	}
	
	@PostMapping("/login")
	User loginUser(@RequestBody LoginUser login) {
		User user = userserv.findUser(login.getUsername(), login.getPassword());
		if(user==null) {
			return null;
		}
		return user;
	}

}
