package com.user.service;

import com.user.dao.entity.User;
import com.user.dto.UserDto;

public interface IUserServ {
	
	User addnewUser(UserDto user);
	User findUser(String username, String password);
}
