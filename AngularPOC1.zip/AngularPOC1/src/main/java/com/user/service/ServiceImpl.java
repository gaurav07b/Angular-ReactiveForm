package com.user.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.dao.entity.Address;
import com.user.dao.entity.PhoneEnt1;
import com.user.dao.entity.PhoneEnt2;
import com.user.dao.entity.User;
import com.user.dao.repo.AddressRepo;
//import com.user.dao.repo.AddressRepo;
import com.user.dao.repo.UserRepo;
import com.user.dto.AddressDto;
import com.user.dto.UserDto;

@Service("servimpl")
public class ServiceImpl implements IUserServ {
	
	@Autowired
	private UserRepo uspo;
	
	@Autowired
	private AddressRepo adpo;
//	private AddressRepo addressrepo;

	@Override
	public User addnewUser(UserDto user) {
		User userent = new User();
		System.out.println(user.getFname());
		Address address = new Address();
		address.setHno(user.getAddress().getHno());
		address.setLocality(user.getAddress().getLocality());
		address.setPin(user.getAddress().getPin());
		address.setState(user.getAddress().getState());
				
		Set<User> userset = new HashSet<>();
		address.setUser(userset);
		
		adpo.save(address);
		
		userent.setFname(user.getFname());
		userent.setLname(user.getLname());
		userent.setUsername(user.getUsername());
		userent.setPassword(user.getPassword());
		userent.setDob(user.getDob());
		
		PhoneEnt1 phent1 = new PhoneEnt1();
		phent1.setArea(user.getContact1().getArea());
		phent1.setTele(user.getContact1().getTele());
		userent.setContact1(phent1);
		phent1.setUser(userent);
		
		PhoneEnt2 phent2 = new PhoneEnt2();
		phent2.setArea(user.getContact2().getArea());
		phent2.setTele(user.getContact2().getTele());
		userent.setContact2(phent2);
		phent2.setUser(userent);
		userset.add(userent);

		userent.setAddress(address);
		uspo.save(userent);
				
		return userent;
	}

	@Override
	public User findUser(String username, String password) {
		User user = uspo.findByUsernameAndPassword(username, password);
		return user;
	}

}
