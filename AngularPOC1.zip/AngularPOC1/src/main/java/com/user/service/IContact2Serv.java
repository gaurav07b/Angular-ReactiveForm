package com.user.service;

import com.user.dto.PhoneDto2;

public interface IContact2Serv {

	void addNewContact(PhoneDto2 phone2);
	
}
