package com.user.service;

import com.user.dao.entity.Address;

public interface IAddressServ {
	
	void addNewAddress(Address address);

}
