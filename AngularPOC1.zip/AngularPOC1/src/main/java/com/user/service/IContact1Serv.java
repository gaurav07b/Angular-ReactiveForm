package com.user.service;

import com.user.dto.PhoneDto1;

public interface IContact1Serv {
	
	void addNewContact(PhoneDto1 phone1);

}
