package com.user.dao.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.user.dao.entity.PhoneEnt1;

@Repository("contact1repo")
public interface Contact1Repo extends JpaRepository<PhoneEnt1, Integer>{

}
